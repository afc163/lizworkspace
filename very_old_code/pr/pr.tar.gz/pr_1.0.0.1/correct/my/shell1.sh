#!/bin/bash
./shell2.sh
echo input a string
read string
echo $string number is: 
grep -c $string ./string.txt
echo details
grep -n $string ./string.txt

cd /home/cjj
cd
./hello1.sh
if [ -z $1 ]
then
cd /home/mp3
./hello2.sh
fi
./hello3.sh

-z: 字符串是否为空

-f 判断文件是否存在

if []
then
fi

for i in $a
do
done

for(())
do
done

while []
do
done

sh +x hellod.sh
 ./hello.sh 1 2
perl perl.pl
python python.py
./aaa.py
aa.py
/bb.pl
HOM='./spring/'
cd $HOM
ccc $HOM/shengyan/test.conf
