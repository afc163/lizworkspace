#!/bin/bash
#编写一个以文件列表作为输入的过滤器程序，要求文件名含有以句点“.”分隔的后缀，过滤器输出每个文件的不带句点和后缀的文件名。

echo "input file names:"
read p
p=`expr $p : '\(.*\)\.'`
echo "output file names:"
echo $p
