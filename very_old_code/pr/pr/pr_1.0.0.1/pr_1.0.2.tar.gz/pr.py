#! /usr/bin/python
#  -*- coding: utf-8 -*-
#  Author : caijunjie
#  Mail   : caijunjie@baidu.com


"""

"""

__revision__ = '0.1'

import os
import sys
import re
#from cjj_op import backup_nsop 
#from batchtools import backup_nsop 
from graph import Graph
from optparse import OptionParser

FILETYPE = {0:'BASH', 1:'PERL', 2:'PYTHON', 3:'C', 4:'CONF', 5:'TXT', 6:'DICT'}

class RelationFiles(object):
    
    def __init__(self, file):
        """
        __init__初始化，当前处理的文件准备
        """
        try:
            self.file_content = open(file).readlines()
            
            #设计需要，RelationFiles类只接收有绝对路径的文件
            #记录当前所走的路径，保存当前路径为file的路径
            self.current_dir = []   
            #dir_tag标记，用于指示下一次改变路径是新增还是修改，0代表修改，1代表新增
            self.dir_tag = []
            self.dir_tag.append(0)
            #file中包涵的子脚本和子程序列表
            self.child_files = {}
            self.file = file
            self.line_num = 0
            if file.startswith('/'):
                self.current_dir.append(file[:file.rfind('/')+1])
            
            #记录该脚本中调用不存在的文件
            self.exist_error_file = []
            #False表示正确，True表示路径解析错误,only one time
            self.path_error_sign = False
            #记录该脚本中错误的路径，文件名：对应的路径
            self.path_error_file = {}
        except IOError, e:
            print e
            raise
    def cd_handle(self, line):
        """
            handle with "cd ./some" "cd /some" "cd $some" "cd ~/some" "cd ../some"
            "cd some" "cd"
        """
        teams = line.split(" ")
        try:
            dir = teams[1]
        except:
            dir = ''
        current_dir = ""
        self.cd_error_sign = 0
        if dir.find('$') != -1:
            #如果cd 后面跟的是变量名，即路径存放在变量中，搜索策略
            current_dir = self.doll_handle(dir)
        else:
            current_dir = self.get_abspath(dir)
        if self.dir_tag[-1] == 0:
            self.current_dir[-1] = current_dir
        elif self.dir_tag[-1] == 1:
            self.current_dir.append(current_dir)
            self.dir_tag[-1] = 0
    
    def get_abspath(self, dir):
        """
        get absolute path: ./ ../ ~/ / ~ --->/somepath/
        """
        if dir.startswith('./'):
            current_dir=self.current_dir[-1]
            current_dir=current_dir[:current_dir.rfind('/')+1]
            dir=dir.replace("./",current_dir)
        elif dir.startswith('ftp://'):
            if dir[6] == '.' or dir[6] == '~':
                dir = self.get_abspath(dir[6:])
            else:
                dir = dir[6:]
        elif dir.startswith('/'):
            pass
        elif dir.startswith('~'):
            dir=dir.replace('~','/home/'+os.getlogin())
        elif dir.startswith('../'):
            current_dir=self.current_dir[-1][:-1]
            temp_dir=dir
            while temp_dir.startswith('../'):
                current_dir=current_dir[:current_dir.rfind('/')]
                temp_dir=temp_dir[3:]
            dir=current_dir+'/'+temp_dir
        elif dir == '':
            #空路径
            dir = os.getcwd()
        else:
            #如 cd somepath
            dir=self.current_dir[-1] + dir
        if dir[-1] != '/':
            return dir+'/'
        else:
            return dir     
    
    def doll_handle(self, variable):
        """
        $: 处理路径中出现$变量的情况，有可能有多个变量组成，无法解析则标记路径
        """
        #路径可能是有多个$组成，目前不支持模块内重名变量
        refh = open(self.file).readlines()
        num = 0
        doll_current_dir = variable
        for line in refh:
            line = line.strip()
            num = num+1
            if num == self.line_num:
                break
            eq_index = line.find('=')
            if eq_index>0:
                #$variable的情况
                temp = '$' + line[:eq_index]
                if doll_current_dir.find(temp) != -1:
                    temp_replace = line[eq_index+2:-1]
                    if temp_replace.endswith('/'):
                        temp_replace = temp_replace[:-1]
                    doll_current_dir = doll_current_dir.replace(temp, temp_replace)
                    continue
                #${variable}的情况
                temp = '${' + line[:eq_index] + '}'
                if doll_current_dir.find(temp) != -1:
                    temp_replace = line[eq_index+2:-1]
                    if temp_replace.endswith('/'):
                        temp_replace = temp_replace[:-1]
                    doll_current_dir=doll_current_dir.replace(temp, temp_replace)
        self.path_error_sign = False
        if '$' in doll_current_dir:
            #无法解析，先做标记，之后记录当前路径
            self.path_error_sign = True
        return self.get_abspath(doll_current_dir)
    
    def find_relation(self):
        """
        find_relation寻找当前file调用的程序、脚本、配置等等文件
        """
        for line in self.file_content:
            line=line.strip()            
            self.line_num=self.line_num+1
            if line.startswith('#') or line=="":
                continue
            
            #获取当前路径
            if line.startswith('cd ') or line == "cd":
                self.cd_handle(line)
                continue
            
            if line.startswith('if ') or line[0:len(line)+1]=='do':
                if self.dir_tag[-1]==1:
                    self.dir_tag.append(1)
                elif self.dir_tag[-1]==0:
                    self.dir_tag[-1]=1
                continue
            if line[0:len(line)+1]=='fi' or line[0:len(line)+1]=='done':
                if self.dir_tag[-1]==1:
                    self.dir_tag[-1]=0
                    if len(self.dir_tag)>1:
                        self.dir_tag.pop()
                elif self.dir_tag[-1]==0:
                    try:
                        self.current_dir.pop()
                    except IndexError,e:
                        print e, self.current_dir, self.dir_tag, line
                        sys.exit(0)
                continue
            
            if line.startswith('wget '):
                #提取主机名和下载目录，但现在是合在一起
                #print '\nftp:',line
                #slash_home_index = line.rfind('/home')
                ftp_index = line.find('ftp://')
                if line.endswith('\"'):
                    line = line[:-1]
                ftp_str = line[ftp_index:]
                #ftp_str = line[ftp_index+6:slash_home_index]
                #if ftp_str.endswith('/'):
                #    ftp_str = ftp_str[:-1]
                if ftp_str.find('$') != -1:
                    ftp_str = self.doll_handle(ftp_str)[:-1]
                else:
                    ftp_str = self.get_abspath(ftp_str)[:-1]
                #download_str = line[slash_home_index:]    
                #if download_str.find('$') != -1:
                #    download_str = self.doll_handle(download_str)[:-1]
                #print 'ftp string:', ftp_str
                #print 'download string:', download_str
                self.add_child(ftp_str)
                continue
            
            if line.startswith('./') or line.startswith('/') or line.startswith('~/') or line.startswith('../'):
                #提取./a(.sh|.py|.pl), /a(.sh|.py|.pl), ~/a(.sh|.py|.pl), ../a(.sh|.py|.pl)
                #C程序只在这边提取
                teams = line.split(' ')
                child_pro = teams[0].strip()
                if child_pro.find('$') != -1:
                    self.add_child(self.doll_handle(child_pro)[:-1])
                else:
                    self.add_child(self.get_abspath(child_pro)[:-1])
                continue
            
            #其他的行使用正则式提取文本中的.sh|.py|.pl|.dict|.txt|.conf文件
            pt_file = re.compile(r'(?P<file>[${}.~/a-zA-Z0-9_-]*\.(sh|py|pl|dict|txt|conf))\b')
            teams = pt_file.findall(line)
            for (one, onetype) in teams:
                if one.find('$') != -1:
                    #print '111111111111111', (one, onetype),'\n'
                    self.add_child(self.doll_handle(one)[:-1])
                else:
                    self.add_child(self.get_abspath(one)[:-1])
            
    def add_child(self, file, ftp_str=None):
        """
        add one child file name：先判断文件是否存在，文件类型和是否已经包含此文件，然后保存
        """
        if ftp_str:#待扩充
            pass
        #判断文件存在错误及路径错误并记录下来
        if self.path_error_sign:
            self.path_error_file[file] = self.current_dir
        elif not os.path.isfile(file):
            self.exist_error_file.append(file)
        
        #获取文件类型
        filename = file[file.rfind('/')+1:]
        dot_index = filename.rfind('.')
        if dot_index != -1:
            type = filename[filename.rfind('.'):]
        else:
            type = '.c'
            
        #将调用的文件保存下来
        if self.child_files.has_key(type):
            if not file in self.child_files[type].keys():
                self.child_files[type][file] = [self.line_num]
            else:
                self.child_files[type][file].append(self.line_num)
        else:
            self.child_files[type] = {file:[self.line_num]}
            
    def get_child_files(self):
        """
        get child files:得到该文件的所有被调用的文件，包括错误的文件
        """
        return self.child_files
    
    def get_exist_error_files(self):
        """
        get exist error files:得到该文件的被调用的错误的文件（文件不存在）
        """
        return self.exist_error_file
    
    def get_path_error_files(self):
        """
        get path error files:得到该文件的中因路径错误的错误文件
        """
        return self.path_error_file
    
def directory_handle(dir):
    """
    directory_handle目录处理：递归寻找子目录及当前目录下的所有文件
    """
    for root, dirs, files in os.walk(dir):
        sub_files = [ os.path.join(root, name) for name in files ]
        sub_files.sort()
        for file in sub_files:
            if file.endswith('.sh'):
                file_handle(file)

def file_handle(file):
    """
    file_handle文件处理：分析shell脚本
    """
    global fr_graph
    if not fr_graph.contains(file):             #是否已经包含shell脚本
        fr_graph.add_node(file, 'yes')          #还没有包含的话就加入，作为新的节点
    if not fr_graph.isHandled(file):            #是否已经处理了
        try:
            file_relation = RelationFiles(file) #处理一个shell脚本
            file_relation.find_relation()       #分析shell脚本
            children = file_relation.get_child_files()
            if not children:                    #一个也没有被调用的文件
                return
            exist_error_file = file_relation.get_exist_error_files()
            path_error_file = file_relation.get_path_error_files()  #所有错误的路径
            #print 'path_error_file',path_error_file.values
            del file_relation
            
            #处理完一个文件后，把结果保存下来，根据需要也可以把错误的文件也保存下来，现在是没有，只是标记了下
            #另外也记录了该shell在第几行调用了被调用文件，可以去掉，换成保存文件的其他信息
            for (child_type, child_dic) in children.items():
                for (one, one_num) in child_dic.items():
                    if not fr_graph.contains(one):
                        exists_sign = 'yes'
                        if one in exist_error_file:
                            exists_sign = 'no'
                        if one in path_error_file.keys():
                            exists_sign = 'no(path: %s not exists)' % path_error_file[one]
                        fr_graph.add_node(one, exists_sign)
                    fr_graph.add_edge(file, one, child_type, one_num)
            #继续处理被调用的shell脚本
            try:
                for sh_child in children['.sh']:
                    file_handle(sh_child)
            except:
                pass
        except IOError,e:
            pass

def get_usage():
    usage = """
        %prog [options] action [applist]:
        action: file relations
        """
    return usage

def directory_option(option, opt, value, parser):
    """directory_option"""
    dir = os.path.abspath(value)
    if os.path.isdir(dir):
        directory_handle(dir)
    else:
        print '%s is not a Directory' % dir

def file_option(option, opt, value, parser):
    """file_option"""
    file_abspath = os.path.abspath(value)
    if os.path.isfile(file_abspath) and file_abspath.endswith('.sh'):
        file_handle(file_abspath)
    else:
        print '%s is not exists or is not a bash script' % file_abspath
        
def read_conf_files(confile):
    """
    read the content from the configure_file,and transform it as a file 
    with abspath
    """    
    try:
        content=open(confile).readlines()
        files=[]
        for line in content:
            line=line.strip()
            if line.startswith('#'):
                continue
            elif line.startswith('/') or line.startswith('./') or line.startswith('~'):
                files.append(os.path.abspath(line))
        return files
    except IOError,e:
        print e, "\nconfigure file: %s not exist\n" % confile
        sys.exit(0)
def configure_option(option, opt, value, parser):
    """configure_option"""
    try:
        dir_or_file=read_conf_files(value)
        for d_or_f in dir_or_file:
            d_or_f=d_or_f.strip()
            if os.path.isdir(d_or_f):
                directory_handle(d_or_f)
            elif os.path.isfile(d_or_f) and d_or_f.endswith('.sh'):
                file_handle(d_or_f)
            else:
                print "this is undefined file/dir"
    except IOError,e:
        print e
        sys.exit(0)
    
def do_main(argv=None):
    """
    main
    """
    if argv is None:
        argv = sys.argv
    parser = OptionParser(usage=get_usage())
    parser.add_option("-d", "--dictory",
                        action="callback",
                        type="string",
                        help="查看一个目录下的文件依赖关系",
                        metavar="string",
                        callback=directory_option)
    parser.add_option("-f", "--file",
                        action="callback",
                        type="string",
                        help="查看某个脚本的依赖关系",
                        metavar="FILE",
                        callback=file_option)
    parser.add_option("-c", "--configure",
                        action="callback",
                        type="string",
                        help="read configuration from FILE",
                        metavar="FILE",
                        callback=configure_option)
    parser.add_option("-y", "--yyy",
                        action="store",
                        type="string",
                        help="use settings in section SEC from config file",
                        metavar="SEC",
                        dest="section")

    (options, args) = parser.parse_args(argv[1:])
    #print options, args
    # 如果没有指定文件和目录，就默认是当前目录
    #if not (options.dictory or options.file):
    #    print options.dictory, options.file
    #    dir=os.path.abspath('pr.py')
    #    dir=dir[:dir.rfind('/')+1]
    #     directory_handle(dir)

if __name__ == "__main__" :
    fr_graph = Graph()
    
    #import hotshot, hotshot.stats
    #prof = hotshot.Profile("pr.prof", 1)
    #prof.runcall(do_main)
    #prof.close()
    #stats = hotshot.stats.load("pr.prof")
    #stats.strip_dirs()
    #stats.sort_stats('time', 'calls')
    #stats.print_stats(20)
        
    do_main()
    print fr_graph